function toggleMessage() {
  const messageBox = document.getElementById('messageBox');
  messageBox.classList.toggle('open');
}
